Object {
[   "error": Object {
    "code": 400,
    "message": "Request payload size exceeds the limit: 10485760 bytes.",
     "status": "INVALID_ARGUMENT",
  },
}


 Object {
[16:54:53]   "code": 403,
[16:54:53]   "details": Array [
[16:54:53]     Object {
[16:54:53]       "@type": "type.googleapis.com/google.rpc.Help",
[16:54:53]       "links": Array [
[16:54:53]         Object {
[16:54:53]           "description": "Google developer console API key",
[16:54:53]           "url": "https://console.developers.google.com/project/874376514949/apiui/credential",
[16:54:53]         },
[16:54:53]       ],
[16:54:53]     },
[16:54:53]   ],
[16:54:53]   "message": "Requests from this Android client application <empty> are blocked.",
[16:54:53]   "status": "PERMISSION_DENIED",
[16:54:53] }



Object {
[17:02:01]   "responses": Array [
[17:02:01]     Object {},
[17:02:01]   ],
[17:02:01] }
[17:02:01] Array [
[17:02:01]   Object {},
[17:02:01] ]




Object {
   "responses": Array [
     Object {
       "fullTextAnnotation": Object {
         "pages": Array [
           Object {
             "blocks": Array [
               Object {
                 "blockType": "TEXT",
                 "boundingBox": Object {
                   "vertices": Array [
                     Object {
                       "x": 417,
                       "y": 175,
                     },
                     Object {
                       "x": 1244,
                       "y": 175,
                     },
                     Object {
                       "x": 1244,
                       "y": 417,
                     },
                     Object {
                       "x": 417,
                       "y": 417,
                     },
                   ],
                 },
                 "paragraphs": Array [
                   Object {
                     "boundingBox": Object {
                       "vertices": Array [
                         Object {
                           "x": 417,
                           "y": 175,
                         },
                         Object {
                           "x": 1244,
                           "y": 175,
                         },
                         Object {
                           "x": 1244,
                           "y": 417,
                         },
                         Object {
                           "x": 417,
                           "y": 417,
                         },
                       ],
                     },
                     "property": Object {
                       "detectedLanguages": Array [
                         Object {
                           "languageCode": "en",
                         },
                       ],
                     },
                     "words": Array [
                       Object {
                         "boundingBox": Object {
                           "vertices": Array [
                             Object {
                               "x": 426,
                               "y": 175,
                             },
                             Object {
                               "x": 703,
                               "y": 187,
                             },
                             Object {
                               "x": 694,
                               "y": 393,
                             },
                             Object {
                               "x": 417,
                               "y": 381,
                             },
                           ],
                         },
                         "property": Object {
                           "detectedLanguages": Array [
                             Object {
                               "languageCode": "en",
                             },
                           ],
                         },
                         "symbols": Array [
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 426,
                                   "y": 175,
                                 },
                                 Object {
                                   "x": 517,
                                   "y": 179,
                                 },
                                 Object {
                                   "x": 508,
                                   "y": 385,
                                 },
                                 Object {
                                   "x": 417,
                                   "y": 381,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "T",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 518,
                                   "y": 179,
                                 },
                                 Object {
                                   "x": 614,
                                   "y": 183,
                                 },
                                 Object {
                                   "x": 605,
                                   "y": 389,
                                 },
                                 Object {
                                   "x": 509,
                                   "y": 385,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "h",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 608,
                                   "y": 234,
                                 },
                                 Object {
                                   "x": 700,
                                   "y": 238,
                                 },
                                 Object {
                                   "x": 693,
                                   "y": 393,
                                 },
                                 Object {
                                   "x": 601,
                                   "y": 389,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedBreak": Object {
                                 "type": "SPACE",
                               },
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "e",
                           },
                         ],
                       },
                       Object {
                         "boundingBox": Object {
                           "vertices": Array [
                             Object {
                               "x": 742,
                               "y": 185,
                             },
                             Object {
                               "x": 1244,
                               "y": 207,
                             },
                             Object {
                               "x": 1234,
                               "y": 417,
                             },
                             Object {
                               "x": 733,
                               "y": 395,
                             },
                           ],
                         },
                         "property": Object {
                           "detectedLanguages": Array [
                             Object {
                               "languageCode": "ms",
                             },
                           ],
                         },
                         "symbols": Array [
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 739,
                                   "y": 240,
                                 },
                                 Object {
                                   "x": 827,
                                   "y": 244,
                                 },
                                 Object {
                                   "x": 820,
                                   "y": 399,
                                 },
                                 Object {
                                   "x": 732,
                                   "y": 395,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "e",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 826,
                                   "y": 188,
                                 },
                                 Object {
                                   "x": 875,
                                   "y": 190,
                                 },
                                 Object {
                                   "x": 866,
                                   "y": 396,
                                 },
                                 Object {
                                   "x": 817,
                                   "y": 394,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "l",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 870,
                                   "y": 240,
                                 },
                                 Object {
                                   "x": 958,
                                   "y": 244,
                                 },
                                 Object {
                                   "x": 951,
                                   "y": 400,
                                 },
                                 Object {
                                   "x": 863,
                                   "y": 396,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "u",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 954,
                                   "y": 240,
                                 },
                                 Object {
                                   "x": 1025,
                                   "y": 243,
                                 },
                                 Object {
                                   "x": 1018,
                                   "y": 398,
                                 },
                                 Object {
                                   "x": 947,
                                   "y": 395,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "s",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 1026,
                                   "y": 243,
                                 },
                                 Object {
                                   "x": 1093,
                                   "y": 246,
                                 },
                                 Object {
                                   "x": 1086,
                                   "y": 401,
                                 },
                                 Object {
                                   "x": 1019,
                                   "y": 398,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "i",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 1094,
                                   "y": 246,
                                 },
                                 Object {
                                   "x": 1165,
                                   "y": 249,
                                 },
                                 Object {
                                   "x": 1158,
                                   "y": 404,
                                 },
                                 Object {
                                   "x": 1087,
                                   "y": 401,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "v",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 1161,
                                   "y": 245,
                                 },
                                 Object {
                                   "x": 1241,
                                   "y": 248,
                                 },
                                 Object {
                                   "x": 1234,
                                   "y": 403,
                                 },
                                 Object {
                                   "x": 1154,
                                   "y": 400,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedBreak": Object {
                                 "type": "EOL_SURE_SPACE",
                               },
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "e",
                           },
                         ],
                       },
                     ],
                   },
                 ],
                 "property": Object {
                   "detectedLanguages": Array [
                     Object {
                       "languageCode": "en",
                     },
                   ],
                 },
               },
               Object {
                 "blockType": "TEXT",
                 "boundingBox": Object {
                   "vertices": Array [
                     Object {
                       "x": 430,
                       "y": 439,
                     },
                     Object {
                       "x": 1226,
                       "y": 439,
                     },
                     Object {
                       "x": 1226,
                       "y": 1073,
                     },
                     Object {
                       "x": 430,
                       "y": 1073,
                     },
                   ],
                 },
                 "paragraphs": Array [
                   Object {
                     "boundingBox": Object {
                       "vertices": Array [
                         Object {
                           "x": 430,
                           "y": 439,
                         },
                         Object {
                           "x": 1226,
                           "y": 439,
                         },
                         Object {
                           "x": 1226,
                           "y": 1073,
                         },
                         Object {
                           "x": 430,
                           "y": 1073,
                         },
                       ],
                     },
                     "property": Object {
                       "detectedLanguages": Array [
                         Object {
                           "languageCode": "en",
                         },
                       ],
                     },
                     "words": Array [
                       Object {
                         "boundingBox": Object {
                           "vertices": Array [
                             Object {
                               "x": 437,
                               "y": 439,
                             },
                             Object {
                               "x": 1226,
                               "y": 458,
                             },
                             Object {
                               "x": 1219,
                               "y": 742,
                             },
                             Object {
                               "x": 430,
                               "y": 723,
                             },
                           ],
                         },
                         "property": Object {
                           "detectedLanguages": Array [
                             Object {
                               "languageCode": "ku",
                             },
                           ],
                         },
                         "symbols": Array [
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 437,
                                   "y": 439,
                                 },
                                 Object {
                                   "x": 574,
                                   "y": 442,
                                 },
                                 Object {
                                   "x": 567,
                                   "y": 726,
                                 },
                                 Object {
                                   "x": 430,
                                   "y": 723,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "B",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 575,
                                   "y": 442,
                                 },
                                 Object {
                                   "x": 680,
                                   "y": 444,
                                 },
                                 Object {
                                   "x": 673,
                                   "y": 720,
                                 },
                                 Object {
                                   "x": 568,
                                   "y": 718,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "I",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 681,
                                   "y": 445,
                                 },
                                 Object {
                                   "x": 786,
                                   "y": 447,
                                 },
                                 Object {
                                   "x": 779,
                                   "y": 723,
                                 },
                                 Object {
                                   "x": 674,
                                   "y": 721,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "G",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 787,
                                   "y": 447,
                                 },
                                 Object {
                                   "x": 892,
                                   "y": 449,
                                 },
                                 Object {
                                   "x": 885,
                                   "y": 725,
                                 },
                                 Object {
                                   "x": 780,
                                   "y": 723,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "T",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 884,
                                   "y": 450,
                                 },
                                 Object {
                                   "x": 997,
                                   "y": 453,
                                 },
                                 Object {
                                   "x": 990,
                                   "y": 729,
                                 },
                                 Object {
                                   "x": 877,
                                   "y": 726,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "E",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 990,
                                   "y": 452,
                                 },
                                 Object {
                                   "x": 1103,
                                   "y": 455,
                                 },
                                 Object {
                                   "x": 1096,
                                   "y": 731,
                                 },
                                 Object {
                                   "x": 983,
                                   "y": 728,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "X",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 1104,
                                   "y": 455,
                                 },
                                 Object {
                                   "x": 1226,
                                   "y": 458,
                                 },
                                 Object {
                                   "x": 1219,
                                   "y": 734,
                                 },
                                 Object {
                                   "x": 1097,
                                   "y": 731,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedBreak": Object {
                                 "type": "EOL_SURE_SPACE",
                               },
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "T",
                           },
                         ],
                       },
                       Object {
                         "boundingBox": Object {
                           "vertices": Array [
                             Object {
                               "x": 439,
                               "y": 770,
                             },
                             Object {
                               "x": 703,
                               "y": 770,
                             },
                             Object {
                               "x": 703,
                               "y": 913,
                             },
                             Object {
                               "x": 439,
                               "y": 913,
                             },
                           ],
                         },
                         "property": Object {
                           "detectedLanguages": Array [
                             Object {
                               "languageCode": "en",
                             },
                           ],
                         },
                         "symbols": Array [
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 439,
                                   "y": 770,
                                 },
                                 Object {
                                   "x": 481,
                                   "y": 770,
                                 },
                                 Object {
                                   "x": 481,
                                   "y": 887,
                                 },
                                 Object {
                                   "x": 439,
                                   "y": 887,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "p",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 482,
                                   "y": 770,
                                 },
                                 Object {
                                   "x": 524,
                                   "y": 770,
                                 },
                                 Object {
                                   "x": 524,
                                   "y": 887,
                                 },
                                 Object {
                                   "x": 482,
                                   "y": 887,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "l",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 525,
                                   "y": 770,
                                 },
                                 Object {
                                   "x": 567,
                                   "y": 770,
                                 },
                                 Object {
                                   "x": 567,
                                   "y": 887,
                                 },
                                 Object {
                                   "x": 525,
                                   "y": 887,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "u",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 568,
                                   "y": 796,
                                 },
                                 Object {
                                   "x": 607,
                                   "y": 796,
                                 },
                                 Object {
                                   "x": 607,
                                   "y": 913,
                                 },
                                 Object {
                                   "x": 568,
                                   "y": 913,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "g",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 608,
                                   "y": 796,
                                 },
                                 Object {
                                   "x": 651,
                                   "y": 796,
                                 },
                                 Object {
                                   "x": 651,
                                   "y": 913,
                                 },
                                 Object {
                                   "x": 608,
                                   "y": 913,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "i",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 655,
                                   "y": 796,
                                 },
                                 Object {
                                   "x": 703,
                                   "y": 796,
                                 },
                                 Object {
                                   "x": 703,
                                   "y": 887,
                                 },
                                 Object {
                                   "x": 655,
                                   "y": 887,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedBreak": Object {
                                 "type": "SPACE",
                               },
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "n",
                           },
                         ],
                       },
                       Object {
                         "boundingBox": Object {
                           "vertices": Array [
                             Object {
                               "x": 744,
                               "y": 770,
                             },
                             Object {
                               "x": 1210,
                               "y": 770,
                             },
                             Object {
                               "x": 1210,
                               "y": 913,
                             },
                             Object {
                               "x": 744,
                               "y": 913,
                             },
                           ],
                         },
                         "property": Object {
                           "detectedLanguages": Array [
                             Object {
                               "languageCode": "en",
                             },
                           ],
                         },
                         "symbols": Array [
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 744,
                                   "y": 799,
                                 },
                                 Object {
                                   "x": 789,
                                   "y": 799,
                                 },
                                 Object {
                                   "x": 789,
                                   "y": 887,
                                 },
                                 Object {
                                   "x": 744,
                                   "y": 887,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "e",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 790,
                                   "y": 799,
                                 },
                                 Object {
                                   "x": 838,
                                   "y": 799,
                                 },
                                 Object {
                                   "x": 838,
                                   "y": 887,
                                 },
                                 Object {
                                   "x": 790,
                                   "y": 887,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "x",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 842,
                                   "y": 799,
                                 },
                                 Object {
                                   "x": 887,
                                   "y": 799,
                                 },
                                 Object {
                                   "x": 887,
                                   "y": 887,
                                 },
                                 Object {
                                   "x": 842,
                                   "y": 887,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "c",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 891,
                                   "y": 770,
                                 },
                                 Object {
                                   "x": 913,
                                   "y": 770,
                                 },
                                 Object {
                                   "x": 913,
                                   "y": 887,
                                 },
                                 Object {
                                   "x": 891,
                                   "y": 887,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "l",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 917,
                                   "y": 799,
                                 },
                                 Object {
                                   "x": 965,
                                   "y": 799,
                                 },
                                 Object {
                                   "x": 965,
                                   "y": 887,
                                 },
                                 Object {
                                   "x": 917,
                                   "y": 887,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "u",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 966,
                                   "y": 799,
                                 },
                                 Object {
                                   "x": 1014,
                                   "y": 799,
                                 },
                                 Object {
                                   "x": 1014,
                                   "y": 887,
                                 },
                                 Object {
                                   "x": 966,
                                   "y": 887,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "s",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 1018,
                                   "y": 770,
                                 },
                                 Object {
                                   "x": 1042,
                                   "y": 770,
                                 },
                                 Object {
                                   "x": 1042,
                                   "y": 887,
                                 },
                                 Object {
                                   "x": 1018,
                                   "y": 887,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "i",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 1041,
                                   "y": 799,
                                 },
                                 Object {
                                   "x": 1089,
                                   "y": 799,
                                 },
                                 Object {
                                   "x": 1089,
                                   "y": 887,
                                 },
                                 Object {
                                   "x": 1041,
                                   "y": 887,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "v",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 1087,
                                   "y": 802,
                                 },
                                 Object {
                                   "x": 1132,
                                   "y": 802,
                                 },
                                 Object {
                                   "x": 1132,
                                   "y": 887,
                                 },
                                 Object {
                                   "x": 1087,
                                   "y": 887,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "e",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 1136,
                                   "y": 773,
                                 },
                                 Object {
                                   "x": 1163,
                                   "y": 773,
                                 },
                                 Object {
                                   "x": 1163,
                                   "y": 887,
                                 },
                                 Object {
                                   "x": 1136,
                                   "y": 887,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "l",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 1162,
                                   "y": 802,
                                 },
                                 Object {
                                   "x": 1210,
                                   "y": 802,
                                 },
                                 Object {
                                   "x": 1210,
                                   "y": 913,
                                 },
                                 Object {
                                   "x": 1162,
                                   "y": 913,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedBreak": Object {
                                 "type": "EOL_SURE_SPACE",
                               },
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "y",
                           },
                         ],
                       },
                       Object {
                         "boundingBox": Object {
                           "vertices": Array [
                             Object {
                               "x": 440,
                               "y": 923,
                             },
                             Object {
                               "x": 853,
                               "y": 920,
                             },
                             Object {
                               "x": 854,
                               "y": 1070,
                             },
                             Object {
                               "x": 441,
                               "y": 1073,
                             },
                           ],
                         },
                         "property": Object {
                           "detectedLanguages": Array [
                             Object {
                               "languageCode": "en",
                             },
                           ],
                         },
                         "symbols": Array [
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 440,
                                   "y": 948,
                                 },
                                 Object {
                                   "x": 490,
                                   "y": 948,
                                 },
                                 Object {
                                   "x": 491,
                                   "y": 1044,
                                 },
                                 Object {
                                   "x": 441,
                                   "y": 1044,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "c",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 491,
                                   "y": 948,
                                 },
                                 Object {
                                   "x": 545,
                                   "y": 948,
                                 },
                                 Object {
                                   "x": 546,
                                   "y": 1044,
                                 },
                                 Object {
                                   "x": 492,
                                   "y": 1044,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "a",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 549,
                                   "y": 947,
                                 },
                                 Object {
                                   "x": 602,
                                   "y": 947,
                                 },
                                 Object {
                                   "x": 603,
                                   "y": 1072,
                                 },
                                 Object {
                                   "x": 550,
                                   "y": 1072,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "p",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 607,
                                   "y": 925,
                                 },
                                 Object {
                                   "x": 647,
                                   "y": 925,
                                 },
                                 Object {
                                   "x": 648,
                                   "y": 1043,
                                 },
                                 Object {
                                   "x": 608,
                                   "y": 1043,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "t",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 648,
                                   "y": 946,
                                 },
                                 Object {
                                   "x": 702,
                                   "y": 946,
                                 },
                                 Object {
                                   "x": 703,
                                   "y": 1042,
                                 },
                                 Object {
                                   "x": 649,
                                   "y": 1042,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "u",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 706,
                                   "y": 946,
                                 },
                                 Object {
                                   "x": 750,
                                   "y": 946,
                                 },
                                 Object {
                                   "x": 751,
                                   "y": 1042,
                                 },
                                 Object {
                                   "x": 707,
                                   "y": 1042,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "r",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 751,
                                   "y": 946,
                                 },
                                 Object {
                                   "x": 799,
                                   "y": 946,
                                 },
                                 Object {
                                   "x": 800,
                                   "y": 1042,
                                 },
                                 Object {
                                   "x": 752,
                                   "y": 1042,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "e",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 800,
                                   "y": 920,
                                 },
                                 Object {
                                   "x": 853,
                                   "y": 920,
                                 },
                                 Object {
                                   "x": 854,
                                   "y": 1041,
                                 },
                                 Object {
                                   "x": 801,
                                   "y": 1041,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedBreak": Object {
                                 "type": "SPACE",
                               },
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "d",
                           },
                         ],
                       },
                       Object {
                         "boundingBox": Object {
                           "vertices": Array [
                             Object {
                               "x": 883,
                               "y": 945,
                             },
                             Object {
                               "x": 992,
                               "y": 944,
                             },
                             Object {
                               "x": 993,
                               "y": 1040,
                             },
                             Object {
                               "x": 884,
                               "y": 1041,
                             },
                           ],
                         },
                         "property": Object {
                           "detectedLanguages": Array [
                             Object {
                               "languageCode": "en",
                             },
                           ],
                         },
                         "symbols": Array [
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 883,
                                   "y": 945,
                                 },
                                 Object {
                                   "x": 937,
                                   "y": 945,
                                 },
                                 Object {
                                   "x": 938,
                                   "y": 1041,
                                 },
                                 Object {
                                   "x": 884,
                                   "y": 1041,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "o",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 938,
                                   "y": 944,
                                 },
                                 Object {
                                   "x": 992,
                                   "y": 944,
                                 },
                                 Object {
                                   "x": 993,
                                   "y": 1040,
                                 },
                                 Object {
                                   "x": 939,
                                   "y": 1040,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedBreak": Object {
                                 "type": "SPACE",
                               },
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "n",
                           },
                         ],
                       },
                       Object {
                         "boundingBox": Object {
                           "vertices": Array [
                             Object {
                               "x": 1021,
                               "y": 918,
                             },
                             Object {
                               "x": 1201,
                               "y": 917,
                             },
                             Object {
                               "x": 1202,
                               "y": 1041,
                             },
                             Object {
                               "x": 1022,
                               "y": 1042,
                             },
                           ],
                         },
                         "property": Object {
                           "detectedLanguages": Array [
                             Object {
                               "languageCode": "sq",
                             },
                           ],
                         },
                         "symbols": Array [
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 1021,
                                   "y": 918,
                                 },
                                 Object {
                                   "x": 1062,
                                   "y": 918,
                                 },
                                 Object {
                                   "x": 1063,
                                   "y": 1042,
                                 },
                                 Object {
                                   "x": 1022,
                                   "y": 1042,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "f",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 1060,
                                   "y": 918,
                                 },
                                 Object {
                                   "x": 1088,
                                   "y": 918,
                                 },
                                 Object {
                                   "x": 1089,
                                   "y": 1042,
                                 },
                                 Object {
                                   "x": 1061,
                                   "y": 1042,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "i",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 1089,
                                   "y": 918,
                                 },
                                 Object {
                                   "x": 1117,
                                   "y": 918,
                                 },
                                 Object {
                                   "x": 1118,
                                   "y": 1042,
                                 },
                                 Object {
                                   "x": 1090,
                                   "y": 1042,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "l",
                           },
                           Object {
                             "boundingBox": Object {
                               "vertices": Array [
                                 Object {
                                   "x": 1118,
                                   "y": 950,
                                 },
                                 Object {
                                   "x": 1201,
                                   "y": 949,
                                 },
                                 Object {
                                   "x": 1202,
                                   "y": 1041,
                                 },
                                 Object {
                                   "x": 1119,
                                   "y": 1042,
                                 },
                               ],
                             },
                             "property": Object {
                               "detectedBreak": Object {
                                 "type": "EOL_SURE_SPACE",
                               },
                               "detectedLanguages": Array [
                                 Object {
                                   "languageCode": "en",
                                 },
                               ],
                             },
                             "text": "m",
                           },
                         ],
                       },
                     ],
                   },
                 ],
                 "property": Object {
                   "detectedLanguages": Array [
                     Object {
                       "languageCode": "en",
                     },
                   ],
                 },
               },
             ],
             "height": 1152,
             "property": Object {
               "detectedLanguages": Array [
                 Object {
                   "languageCode": "en",
                 },
               ],
             },
             "width": 1536,
           },
         ],
         "text": "The elusive
 BIGTEXT
 plugin exclusively
 captured on film
 ",
       },
       "textAnnotations": Array [
         Object {
           "boundingPoly": Object {
             "vertices": Array [
               Object {
                 "x": 417,
                 "y": 175,
               },
               Object {
                 "x": 1244,
                 "y": 175,
               },
               Object {
                 "x": 1244,
                 "y": 1073,
               },
               Object {
                 "x": 417,
                 "y": 1073,
               },
             ],
           },
           "description": "The elusive
 BIGTEXT
 plugin exclusively
 captured on film
 ",
           "locale": "en",
         },
         Object {
           "boundingPoly": Object {
             "vertices": Array [
               Object {
                 "x": 426,
                 "y": 175,
               },
               Object {
                 "x": 703,
                 "y": 187,
               },
               Object {
                 "x": 694,
                 "y": 393,
               },
               Object {
                 "x": 417,
                 "y": 381,
               },
             ],
           },
           "description": "The",
         },
         Object {
           "boundingPoly": Object {
             "vertices": Array [
               Object {
                 "x": 742,
                 "y": 185,
               },
               Object {
                 "x": 1244,
                 "y": 207,
               },
               Object {
                 "x": 1234,
                 "y": 417,
               },
               Object {
                 "x": 733,
                 "y": 395,
               },
             ],
           },
           "description": "elusive",
         },
         Object {
           "boundingPoly": Object {
             "vertices": Array [
               Object {
                 "x": 437,
                 "y": 439,
               },
               Object {
                 "x": 1226,
                 "y": 458,
               },
               Object {
                 "x": 1219,
                 "y": 742,
               },
               Object {
                 "x": 430,
                 "y": 723,
               },
             ],
           },
           "description": "BIGTEXT",
         },
         Object {
           "boundingPoly": Object {
             "vertices": Array [
               Object {
                 "x": 439,
                 "y": 770,
               },
               Object {
                 "x": 703,
                 "y": 770,
               },
               Object {
                 "x": 703,
                 "y": 913,
               },
               Object {
                 "x": 439,
                 "y": 913,
               },
             ],
           },
           "description": "plugin",
         },
         Object {
           "boundingPoly": Object {
             "vertices": Array [
               Object {
                 "x": 744,
                 "y": 770,
               },
               Object {
                 "x": 1210,
                 "y": 770,
               },
               Object {
                 "x": 1210,
                 "y": 913,
               },
               Object {
                 "x": 744,
                 "y": 913,
               },
             ],
           },
           "description": "exclusively",
         },
         Object {
           "boundingPoly": Object {
             "vertices": Array [
               Object {
                 "x": 440,
                 "y": 923,
               },
               Object {
                 "x": 853,
                 "y": 920,
               },
               Object {
                 "x": 854,
                 "y": 1070,
               },
               Object {
                 "x": 441,
                 "y": 1073,
               },
             ],
           },
           "description": "captured",
         },
         Object {
           "boundingPoly": Object {
             "vertices": Array [
               Object {
                 "x": 883,
                 "y": 945,
               },
               Object {
                 "x": 992,
                 "y": 944,
               },
               Object {
                 "x": 993,
                 "y": 1040,
               },
               Object {
                 "x": 884,
                 "y": 1041,
               },
             ],
           },
           "description": "on",
         },
         Object {
           "boundingPoly": Object {
             "vertices": Array [
               Object {
                 "x": 1021,
                 "y": 918,
               },
               Object {
                 "x": 1201,
                 "y": 917,
               },
               Object {
                 "x": 1202,
                 "y": 1041,
               },
               Object {
                 "x": 1022,
                 "y": 1042,
               },
             ],
           },
           "description": "film",
         },
       ],
     },
   ],
 }
