export const firebaseConfig = {
  apiKey: "AIzaSyAHsGPOHBgvK2l-hdOYSUOuQrMp2PZwo-k",
  authDomain: "verity-ebd35.firebaseapp.com",
  databaseURL: "https://verity-ebd35.firebaseio.com/",
  projectId: "verity-ebd35",
  storageBucket: "gs://verity-ebd35.appspot.com",
  messagingSenderId: "874376514949",
}