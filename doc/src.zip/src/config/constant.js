export const apiUrl = "https://t.verity.bz/index.php?option=com_jewebservices&task=";

export const facebookId = "288648678174508";


export const androidGoogleClientId= '31022361841-7431bfbrm8qidpd9l7m9cldn1vd3nl65.apps.googleusercontent.com';
export const iosGoogleClientId= '31022361841-ms9vr5360tbsfa06tmd8dr1duf493e1o.apps.googleusercontent.com';
// export const androidGoogleClientId="874376514949-5o4ds9883eri3lph36iibe3ui4qj2kqf.apps.googleusercontent.com";
// export const iosGoogleClientId="874376514949-5o4ds9883eri3lph36iibe3ui4qj2kqf.apps.googleusercontent.com";

export const ocrGoogleAPIURL="https://vision.googleapis.com/v1/images:annotate?key="

export const  ocrIOSKEY = "AIzaSyDQe2EsLCGVNvelPqHKuKj6IqEyG55x8bg";

// export const  ocrAndroidKEY = "AIzaSyC2OeK6r7zlqXDsEYEC2xCcAa08w7J7euI"; 
export const ocrBundleID="com.certified.verityscanning";
export const  ocrAndroidKEY = "AIzaSyDnvz6A0jktKUhgFl3XWI1TWa1WT_Jn_e4";


export const splashAPIKey="AIzaSyDnvz6A0jktKUhgFl3XWI1TWa1WT_Jn_e4";

export const firebaseConfig = {
  apiKey: "AIzaSyAHsGPOHBgvK2l-hdOYSUOuQrMp2PZwo-k",
  authDomain: "verity-ebd35.firebaseapp.com",
  databaseURL: "https://verity-ebd35.firebaseio.com/",
  projectId: "verity-ebd35",
  storageBucket: "gs://verity-ebd35.appspot.com",
  messagingSenderId: "874376514949",
}

export const netErrorMsg="You're not connected to the internet.\n Please connect and retry.";